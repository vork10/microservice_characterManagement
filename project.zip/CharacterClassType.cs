public enum CharacterClassType
{
    Warrior,
    Mage,
    Rogue
}