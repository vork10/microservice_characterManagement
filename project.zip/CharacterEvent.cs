public class CharacterEvent
{
    public int Id { get; set; }
    public EventType EventType { get; set; }
    public DateTime EventDate { get; set; }
    public string Details { get; set; }
}