public enum EventType
{
    Created,
    Updated,
    Deleted
}